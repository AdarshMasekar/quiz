import React, { useState, useEffect } from 'react';
import questionsData from '../data/questions';

const QuizCreation = () => {
  const [questions, setQuestions] = useState(questionsData);
  const [questionText, setQuestionText] = useState('');
  const [options, setOptions] = useState(['', '', '', '']);
  const [correctOption, setCorrectOption] = useState('');

  useEffect(() => {
    // Load questions from localStorage or use default questions
    const savedQuestions = JSON.parse(localStorage.getItem('questions')) || questionsData;
    setQuestions(savedQuestions);
  }, []);

  const handleAddQuestion = () => {
    const newQuestions = [
      ...questions,
      {
        question: questionText,
        options: options,
        correct: correctOption
      }
    ];
    setQuestions(newQuestions);
    localStorage.setItem('questions', JSON.stringify(newQuestions)); // Save updated questions to localStorage

    setQuestionText('');
    setOptions(['', '', '', '']);
    setCorrectOption('');
  };

  return (
    <div>
      <h2>Create Quiz</h2>
      <input 
        type="text" 
        placeholder="Enter question" 
        value={questionText} 
        onChange={(e) => setQuestionText(e.target.value)} 
      />
      {options.map((option, index) => (
        <input 
          key={index} 
          type="text" 
          placeholder={`Option ${index + 1}`} 
          value={option} 
          onChange={(e) => {
            const newOptions = [...options];
            newOptions[index] = e.target.value;
            setOptions(newOptions);
          }} 
        />
      ))}
      <select value={correctOption} onChange={(e) => setCorrectOption(e.target.value)}>
        <option value="">Select correct option</option>
        {options.map((option, index) => (
          <option key={index} value={option}>{option}</option>
        ))}
      </select>
      <button onClick={handleAddQuestion}>Add Question</button>
      <ul>
        {questions.map((q, index) => (
          <li key={index}>{q.question}</li>
        ))}
      </ul>
    </div>
  );
};

export default QuizCreation;
