// App.js
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Home from './components/Home';
import QuizCreation from './components/QuizCreation';
import QuizTaking from './components/QuizTaking';
import QuizResults from './components/QuizResults';
import Login from './components/Login';
import Register from './components/Register';
import AdminDashboard from './components/AdminDashboard';
import UserDashboard from './components/UserDashboard';
import questions from './data/questions'; // Import the questions

function App() {
  const [user, setUser] = useState(null); // State to track the logged-in use
  // On component mount, check if user is already logged in
  useEffect(() => {
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
    if (loggedInUser) {
      setUser(loggedInUser); // Set the logged-in user state from localStorage
    }
  }, []);
  const handleLogout = () => {
    setUser(null); // Clear the user state
    localStorage.removeItem('loggedInUser'); // Clear the logged-in user from localStorage
  };
  
  return (
    <Router>
      <div>
        {user && <button onClick={handleLogout}>Logout</button>}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login setUser={setUser} />} />
          <Route path="/register" element={<Register />} />
          {/* Role-based routes */}
          {user ? (
            <>
              {user.role === 'admin' ? (
                <>
                  <Route path="/admin" element={<AdminDashboard />} />
                  <Route path="/create" element={<QuizCreation />} />
                  <Route path="/results" element={<QuizResults />} />
                </>
              ) : (
                <>
                  <Route path="/user" element={<UserDashboard />} />
                  <Route path="/take" element={<QuizTaking questions={questions} />} />
                  <Route path="/results" element={<QuizResults />} />
                </>
              )}
              <Route path="*" element={<Navigate to={user.role === 'admin' ? '/admin' : '/user'} />} />
            </>
          ) : (
            <>
              <Route path="*" element={<Navigate to="/login" />} />
            </>
          )}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
