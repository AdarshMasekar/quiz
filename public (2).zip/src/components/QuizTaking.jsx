import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import questionsData from '../data/questions'; // Import quiz questions

// Function to get a random subset of questions
const getRandomQuestions = (questions, num) => {
  const shuffled = [...questions].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, num);
};

const QuizTaking = () => {
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState([]);
  const [timeLeft, setTimeLeft] = useState(20 * 60); // 20 minutes in seconds
  const [quizStarted, setQuizStarted] = useState(false);
  const [showAllQuestions, setShowAllQuestions] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Choose 20 random questions
    setQuestions(getRandomQuestions(questionsData, 20));
  }, []);

  useEffect(() => {
    let timer;
    if (quizStarted) {
      timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);

      if (timeLeft === 0) {
        handleSubmit(); // Submit quiz when time is up
      }
    }
    return () => clearInterval(timer);
  }, [timeLeft, quizStarted]);

  const handleAnswerChange = (answer, index) => {
    const updatedAnswers = [...selectedAnswers];
    updatedAnswers[index] = answer;
    setSelectedAnswers(updatedAnswers);
  };

  const handleSubmit = () => {
    const results = {
      selectedAnswers,
      timeTaken: 20 * 60 - timeLeft, // Time taken to complete the quiz
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('quizResults', JSON.stringify(results)); // Store results in localStorage
    navigate('/results');
  };

  // Check if there are no questions or currentQuestionIndex is out of bounds
  if (!questions || questions.length === 0 || !questions[currentQuestionIndex]) {
    return <p>No questions available or invalid question index.</p>;
  }

  if (!quizStarted) {
    return (
      <div>
        <h2>Ready to start the quiz?</h2>
        <button onClick={() => setQuizStarted(true)}>Start Quiz</button>
      </div>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div style={{ display: 'flex' }}>
      {/* Sidebar */}
      <div style={{ width: '200px', padding: '10px', borderRight: '1px solid #ddd' }}>
        <button onClick={() => setShowAllQuestions(!showAllQuestions)}>
          {showAllQuestions ? 'Show Sidebar' : 'Show All Questions'}
        </button>
        {!showAllQuestions && (
          <ul>
            {questions.map((_, index) => (
              <li key={index}>
                <button onClick={() => setCurrentQuestionIndex(index)}>
                  Question {index + 1}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Main Content */}
      <div style={{ flex: 1, padding: '10px' }}>
        {showAllQuestions ? (
          <div>
            <h2>All Questions</h2>
            {questions.map((q, index) => (
              <div key={index}>
                <p><strong>{q.question}</strong></p>
                <ul>
                  {q.options.map((opt, idx) => (
                    <li key={idx}>{opt} {opt === q.correct && '(Correct)'}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        ) : (
          <div>
            <h2>Quiz in Progress</h2>
            <p>Time left: {Math.floor(timeLeft / 60)}:{('0' + (timeLeft % 60)).slice(-2)}</p>
            <div>
              <p>{currentQuestion.question}</p>
              {currentQuestion.options.map((option, index) => (
                <div key={index}>
                  <input
                    type="radio"
                    name={`question-${currentQuestionIndex}`}
                    value={option}
                    onChange={() => handleAnswerChange(option, currentQuestionIndex)}
                    checked={selectedAnswers[currentQuestionIndex] === option}
                  />
                  {option}
                </div>
              ))}
            </div>
            <button
              onClick={() => setCurrentQuestionIndex(currentQuestionIndex + 1)}
              disabled={currentQuestionIndex === questions.length - 1}
            >
              Next Question
            </button>
            {currentQuestionIndex === questions.length - 1 && (
              <button onClick={handleSubmit}>Submit</button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default QuizTaking;
