// Home.js
import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div>
      <h1>Welcome to the Quiz Platform</h1>
      <nav>
        <ul>
          <li><Link to="/create">Create a Quiz</Link></li>
          <li><Link to="/take">Take a Quiz</Link></li>
          <li><Link to="/results">View Results</Link></li>
        </ul>
      </nav>
    </div>
  );
};

export default Home;
