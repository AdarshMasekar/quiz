// UserDashboard.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';

const UserDashboard = () => {
  const navigate = useNavigate(); // useNavigate hook for navigation

  const handleTakeQuiz = () => {
    navigate('/take'); // Navigate to the quiz-taking page
  };

  const handleViewResults = () => {
    navigate('/results'); // Navigate to the quiz results page
  };

  return (
    <div>
      <h2>User Dashboard</h2>
      <button onClick={handleTakeQuiz}>Take Quiz</button>
      <button onClick={handleViewResults}>View Past Results</button>
    </div>
  );
};

export default UserDashboard;
