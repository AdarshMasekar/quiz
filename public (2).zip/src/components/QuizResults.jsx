import React, { useEffect, useState } from 'react';

const QuizResults = () => {
  const [results, setResults] = useState(null);
  const [correctCount, setCorrectCount] = useState(0);
  const [incorrectCount, setIncorrectCount] = useState(0);
  const correctAnswers = [
    "Paris", "Mars", "Pacific Ocean", "William Shakespeare", "Cell", 
    "1945", "Albert Einstein", "Mount Everest", "H2O", "Africa", 
    "Elon Musk", "Diamond", "100°C", "Australia", "8", 
    "Leonardo da Vinci", "Carbon Dioxide", "Avocado", "Blue Whale", "Tokyo", 
    "Mercury", "Barometer", "Elephant", "Carbon", "Alexander Fleming"
  ]; // Replace this with actual correct answers

  useEffect(() => {
    const storedResults = JSON.parse(localStorage.getItem('quizResults'));

    if (storedResults) {
      const userAnswers = storedResults.selectedAnswers;
      let correct = 0;
      let incorrect = 0;

      // Compare user answers with correct answers
      userAnswers.forEach((answer, index) => {
        if (answer === correctAnswers[index]) {
          correct += 1;
        } else {
          incorrect += 1;
        }
      });

      setResults(storedResults);
      setCorrectCount(correct);
      setIncorrectCount(incorrect);
    }
  }, []);

  if (!results) {
    return <p>No quiz results available.</p>;
  }

  return (
    <div>
      <h2>Quiz Results</h2>
      <p>Time taken: {Math.floor(results.timeTaken / 60)}:{('0' + (results.timeTaken % 60)).slice(-2)}</p>
      <p>Correct Answers: {correctCount}</p>
      <p>Incorrect Answers: {incorrectCount}</p>
      <p>Date: {new Date(results.timestamp).toLocaleString()}</p>
      <h3>Your Answers:</h3>
      <ul>
        {results.selectedAnswers.map((answer, index) => (
          <li key={index}>
            Q{index + 1}: {answer || 'No answer'} (Correct: {correctAnswers[index]})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default QuizResults;
