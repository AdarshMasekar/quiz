const questions = [
  // Java-related questions
  {
    question: "Which keyword is used to define a class in Java?",
    options: ["class", "define", "create", "new"],
    correct: "class"
  },
  {
    question: "What is the default value of a boolean variable in Java?",
    options: ["true", "false", "0", "null"],
    correct: "false"
  },
  {
    question: "Which method is used to start a thread in Java?",
    options: ["run()", "start()", "init()", "execute()"],
    correct: "start()"
  },
  // JavaScript-related questions
  {
    question: "Which operator is used to compare values in JavaScript?",
    options: ["=", "==", "===", "!="],
    correct: "==="
  },
  {
    question: "How do you declare a variable in JavaScript?",
    options: ["var", "let", "const", "All of the above"],
    correct: "All of the above"
  },
  {
    question: "What does the `console.log()` method do in JavaScript?",
    options: ["Logs a message to the console", "Displays an alert", "Writes to a file", "None of the above"],
    correct: "Logs a message to the console"
  },
  // Python-related questions
  {
    question: "Which symbol is used for comments in Python?",
    options: ["//", "#", "/*", "<!--"],
    correct: "#"
  },
  {
    question: "How do you define a function in Python?",
    options: ["def functionName():", "function functionName[]", "function functionName():", "define functionName():"],
    correct: "def functionName():"
  },
  {
    question: "Which method is used to remove an item from a list in Python?",
    options: ["remove()", "del", "pop()", "All of the above"],
    correct: "All of the above"
  }
];

export default questions;
